import boto3
import sys
import botocore
from botocore.exceptions import ClientError

con=boto3.session.Session(profile_name='pradip')
ec2_con_res=con.resource(service_name='ec2', region_name='us-west-1')

while True:
    print("This script performs following tasks on ec2 instances")
    print("""
            1. Start
            2. Stop
            3. Terminate
            4. Exit""")
    opt=int(input("Enter your option: "))
    if opt in range(1,4):
        inst_id=input("Enter instance id: ")
        try:
            my_inst_obj=ec2_con_res.Instance(inst_id)
        except Exception as error:
            raise ValueError('The instance Id you provided is incorrect: {}'.format(error))
            sys.exit()
    if opt==1:
        print("Starting ec2 instance....")
        my_inst_obj.start()
    elif opt==2:
        print("Stopping ec2 instance....")
        my_inst_obj.stop()
    elif opt==3:
        print("Terminating ec2 instance....")
        my_inst_obj.terminate()
    elif opt==4:
        sys.exit()
    else:
        print("Invalid option. Please try again")
