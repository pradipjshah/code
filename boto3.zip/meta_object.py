import boto3

aws_man_con=boto3.session.Session(profile_name='pradip')
res=aws_man_con.resource(service_name='ec2', region_name='us-west-1')

for each in res.meta.client.describe_regions()['Regions']:
    print(each['RegionName'])
