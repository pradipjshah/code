import boto3
from pprint import pprint

aws_mag_con=boto3.session.Session(profile_name='pradip')
client=aws_mag_con.client('ec2')

ids = []
while True:
    user_input = input("Enter Instance ID: ")
    if len(user_input) == 0:
        break
    else:
        ids.append(user_input)

if len(ids) == 0:
    F1={'Name':'instance-state-name', 'Values': ['running']}
    response = client.describe_instance_status(Filters=[F1])

    for item in response['InstanceStatuses']:
        response = client.start_instances(InstanceIds=[item['InstanceId']])
        pprint(response)
else:
    response = client.start_instances(InstanceIds=ids)
    pprint(response)
