import boto3
from pprint import pprint

con=boto3.session.Session(profile_name="pradip")
client=con.client(service_name='ec2', region_name='us-west-1')

response = client.describe_instances()

for items in response['Reservations']:
    for each in items['Instances']:
        print("ID: {} Type: {} Time: {} State: {} Tag: {}".format(each['InstanceId'], each['InstanceType'], each['LaunchTime'].strftime("%Y-%m-%d"), each['State']["Name"], each['Tags']))

for each in client.describe_volumes()['Volumes']:
    print("VolID {}\n   Type {} State {}".format(each['VolumeId'], each['VolumeType'], each['State']))
