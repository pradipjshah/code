import boto3

class InstanceMgmt:
    def __init__(self, InstId):
        self.con=boto3.session.Session(profile_name="pradip")
        self.res=self.con.resource(service_name='ec2', region_name='us-west-1')
        self.my_inst_obj=self.res.Instance(InstId)

    def start_inst(self):
        self.my_inst_obj.start()
        self.my_inst_obj.wait_until_running()
        return "Instance is up"

    def stop_inst(self):
        self.my_inst_obj.stop()
        self.my_inst_obj.wait_until_stopped()
        return "Instance is down"

my_inst_id=input("Enter instance id: ")
con=InstanceMgmt(my_inst_id)
status=con.start_inst()
status=con.stop_inst()
print(status)

# "i-055cd979ce4c890f1"
