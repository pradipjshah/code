import boto3
from pprint import pprint

con=boto3.session.Session(profile_name='pradip')
client = con.client(service_name='elbv2')

for item in client.describe_load_balancers()['LoadBalancers']:
    print(item['LoadBalancerName'])
    zones=[]
    for zone in item['AvailabilityZones']:
        print(zone['ZoneName'])
        zones.append(zone['ZoneName'])
    pprint(zones)
