import boto3

con=boto3.session.Session(profile_name="pradip")
client = con.client(service_name="sts", region_name="us-west-1")

response = client.get_caller_identity()

for key,value in response.items():
    print("key: {} Value: {}".format(key, value) )
print()
print(response.get("Account"))
