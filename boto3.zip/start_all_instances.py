import boto3
cons=boto3.session.Session(profile_name='pradip')
res=cons.resource(service_name='ec2', region_name='us-west-1')
client=cons.client(service_name='ec2', region_name='us-west-1')

all_instances_ids=[]
for each in res.instances.all():
    all_instances_ids.append(each.instance_id)
'''
waiter = client.get_waiter('instance_running')
res.instances.start()
waiter.wait(InstanceIds=all_instances_ids)
print('All instances started')
'''
waiter = client.get_waiter('instance_stopped')
res.instances.stop()
waiter.wait(InstanceIds=all_instances_ids)
print('All instances stopped')
