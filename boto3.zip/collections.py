import boto3
cons=boto3.session.Session(profile_name='pradip')
res=cons.resource(service_name='ec2', region_name='us-west-1')

f1={'Name': 'instance-state-name', 'Values': ['stopped']}
for each in res.instances.filter(Filters=[f1]):
    print(each.instance_id, each.instance_type, each.platform)
